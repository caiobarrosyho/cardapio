<?php
session_start();
require __DIR__ . '/funcoes_carrinho.php';

$dataFile = __DIR__ . '/data/produtos.json';
$json  = file_get_contents($dataFile);
$dados = json_decode($json, true);

$loja       = $dados['loja'] ?? [];
$categorias = $dados['categorias'] ?? [];

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$tipoLoja      = $loja['tipo'] ?? 'Salgados';
$tempoEntrega  = $loja['tempo_entrega'] ?? '45–51 min';
$pedidoMinimo  = isset($loja['pedido_minimo']) ? (float)$loja['pedido_minimo'] : 20.00;
$textoEntrega  = $loja['texto_entrega'] ?? 'A gente leva até você';
$textoRetirada = $loja['texto_retirada'] ?? 'Você retira no local';
$taxaPadrao    = isset($loja['taxa_padrao']) ? (float)$loja['taxa_padrao'] : 5.99;
$taxaRapida    = isset($loja['taxa_rapida']) ? (float)$loja['taxa_rapida'] : 8.99;

$slots = [
  '11:00–11:30',
  '12:00–12:30',
  '12:30–13:00',
  '13:00–13:30',
  '13:30–14:00',
  '14:00–14:30',
];

$descricaoLoja = $loja['descricao'] ?? ($loja['slogan'] ?? '');
$cnpjLoja      = $loja['cnpj']      ?? '';

// endereço curto do topo (usado no modal também, se precisar)
$endTopo = $loja['endereco_topo']
  ?? ($loja['endereco_curto']
  ?? ($loja['endereco'] ?? 'Endereço não configurado'));

// WhatsApp da loja
$whatsLoja    = $loja['whatsapp'] ?? '';
$whatsDigitos = preg_replace('/\D+/', '', $whatsLoja);
$whatsLink    = $whatsDigitos ? 'https://wa.me/55' . $whatsDigitos : '';
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title><?php echo h($loja['nome'] ?? 'Cardápio'); ?></title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="assets/style.css?v=10">
</head>
<body>

<?php include __DIR__ . '/header_topo.php'; ?>

<div class="main">
  <div class="hero-wrapper">
    <div class="hero-banner-area">
      <div class="hero-banner">
        <?php if (!empty($loja['banner'])): ?>
          <img src="<?php echo h($loja['banner']); ?>" alt="Banner">
        <?php endif; ?>
      </div>
    </div>

    <div class="hero-restaurant">
      <div class="hero-card">
        <div class="hero-logo">
          <?php if (!empty($loja['logo'])): ?>
            <img src="<?php echo h($loja['logo']); ?>" alt="Logo">
          <?php endif; ?>
        </div>
        <div class="hero-info">
          <div class="hero-name"><?php echo h($loja['nome'] ?? 'Minha Loja'); ?></div>
          <div class="hero-type"><?php echo h($tipoLoja); ?></div>
          <div class="hero-slogan"><?php echo h($loja['slogan'] ?? ''); ?></div>

          <div class="hero-meta">
            <button type="button" class="link-vermais" id="btnSobreLoja">Ver mais</button>
            <span class="hero-meta-sep">|</span>
            <span class="hero-minimo">
              Pedido mínimo R$ <?php echo number_format($pedidoMinimo, 2, ',', '.'); ?>
            </span>
            <?php if ($whatsLink): ?>
              <span class="hero-meta-sep">|</span>
              <a href="<?php echo h($whatsLink); ?>" target="_blank" class="btn-whats-loja">
                WhatsApp da loja
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="hero-toolbar">
      <div class="hero-toolbar-inner">
        <div class="search-cardapio">
          <input type="text" id="busca" placeholder="Buscar no cardápio">
        </div>
        <button type="button" class="select-box select-btn" id="btnTipoEntrega">
          <span id="textoTipoEntrega">Entrega</span>
          <span>▾</span>
        </button>
        <button type="button" class="select-box select-btn" id="btnDiaEntrega">
          <span id="textoDiaEntrega">Hoje</span>
          <span>▾</span>
        </button>
      </div>
    </div>
  </div>

  <div class="page-body">
    <div class="content">
      <?php foreach ($categorias as $cat): ?>
        <section class="categoria" data-categoria="<?php echo h($cat['titulo']); ?>">
          <h2 class="categoria-titulo"><?php echo h($cat['titulo']); ?></h2>

          <div class="grid-produtos">
          <?php foreach ($cat['produtos'] as $prod): ?>
            <?php
              // se tiver campo "ativo" e for 0, não mostra
              $ativo = !isset($prod['ativo']) || (int)$prod['ativo'] === 1;
              if (!$ativo) continue;

              $temPromo = !empty($prod['preco_original']) &&
                          $prod['preco_original'] > $prod['preco'];
              $idProd   = $prod['id'] ?? md5($prod['nome'] . $prod['preco']);
              $foto     = $prod['foto'] ?? '';
            ?>
            <article class="card-produto"
              data-id="<?php echo h($idProd); ?>"
              data-nome="<?php echo h($prod['nome']); ?>"
              data-desc="<?php echo h($prod['descricao']); ?>"
              data-detalhe="<?php echo h($prod['detalhe'] ?? ''); ?>"
              data-preco="<?php echo h(number_format($prod['preco'], 2, '.', '')); ?>"
              data-preco-original="<?php echo $temPromo ? h(number_format($prod['preco_original'], 2, '.', '')) : ''; ?>"
              data-foto="<?php echo h($foto); ?>"
            >
              <div class="card-info">
                <div>
                  <div class="card-nome"><?php echo h($prod['nome']); ?></div>
                  <div class="card-descricao"><?php echo h($prod['descricao']); ?></div>
                  <?php if (!empty($prod['detalhe'])): ?>
                  <div class="card-detalhe"><?php echo h($prod['detalhe']); ?></div>
                  <?php endif; ?>
                </div>
                <div>
                  <div class="card-preco <?php echo $temPromo ? 'promo' : ''; ?>">
                    R$ <?php echo number_format($prod['preco'], 2, ',', '.'); ?>
                    <?php if ($temPromo): ?>
                      <small>R$ <?php echo number_format($prod['preco_original'], 2, ',', '.'); ?></small>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="card-imagem">
                <?php if (!empty($foto)): ?>
                  <img src="<?php echo h($foto); ?>" alt="<?php echo h($prod['nome']); ?>">
                <?php endif; ?>
              </div>
            </article>
          <?php endforeach; ?>
          </div>
        </section>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- MODAL COMO QUER RECEBER -->
<div class="modal-backdrop" id="modalEntrega">
  <div class="modal">
    <div class="modal-title">Como quer receber o pedido?</div>
    <div class="modal-options" id="opcoesEntrega">
      <div class="modal-option active" data-tipo="Entrega">
        <div class="modal-option-left">
          <div class="modal-option-title">Entrega</div>
          <div class="modal-option-desc"><?php echo h($textoEntrega); ?></div>
        </div>
        <div class="modal-option-right"></div>
      </div>
      <div class="modal-option" data-tipo="Retirada">
        <div class="modal-option-left">
          <div class="modal-option-title">Retirada</div>
          <div class="modal-option-desc"><?php echo h($textoRetirada); ?></div>
        </div>
        <div class="modal-option-right"></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-red" id="btnConfirmarEntrega">Confirmar entrega</button>
    </div>
  </div>
</div>

<!-- MODAL HORÁRIO -->
<div class="modal-backdrop" id="modalHorario">
  <div class="modal">
    <div class="modal-horario-header">
      <div class="modal-dia-atual">Hoje</div>
      <div class="modal-horario-col">
        <div style="font-size:12px;font-weight:600;">Horário de entrega</div>
        <div style="font-size:11px;color:#777;">Para agora e agendamento</div>
      </div>
    </div>

    <div class="modal-subtitle">Para agora</div>
    <div class="modal-horario-lista">
      <div class="modal-horario-item">
        <span>Padrão<br><span style="color:#777;">49–59 min</span></span>
        <span>R$ <?php echo number_format($taxaPadrao, 2, ',', '.'); ?></span>
      </div>
      <div class="modal-horario-item">
        <span>Rápida<br><span style="color:#777;">40–50 min</span></span>
        <span>R$ <?php echo number_format($taxaRapida, 2, ',', '.'); ?></span>
      </div>

      <div class="modal-subtitle" style="margin-top:10px;">Agendamento</div>
      <?php foreach ($slots as $slot): ?>
      <div class="modal-horario-item">
        <span><?php echo h($slot); ?></span>
        <span>R$ <?php echo number_format($taxaPadrao, 2, ',', '.'); ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="modal-footer" style="margin-top:12px;">
      <button class="btn btn-red" id="btnConfirmarHorario">Confirmar horário</button>
    </div>
  </div>
</div>

<!-- MODAL SOBRE / HORÁRIO / PAGAMENTO DA LOJA -->
<div class="modal-backdrop" id="modalLoja">
  <div class="modal modal-loja">
    <button type="button" class="modal-close" id="mlFechar">×</button>

    <div class="ml-tabs">
      <button type="button" class="ml-tab active" data-tab="sobre">Sobre</button>
      <button type="button" class="ml-tab" data-tab="horario">Horário</button>
      <button type="button" class="ml-tab" data-tab="pagamento">Pagamento</button>
    </div>

    <div class="ml-conteudo" id="tab-sobre">
      <?php if ($descricaoLoja): ?>
      <p class="ml-texto">
        <?php echo nl2br(h($descricaoLoja)); ?>
      </p>
      <?php endif; ?>

      <h3>Endereço</h3>
      <p class="ml-texto">
        <?php echo h($loja['endereco'] ?? ''); ?>
        <?php if (!empty($loja['complemento'])): ?><br><?php echo h($loja['complemento']); ?><?php endif; ?>
        <br>
        <?php echo h(($loja['bairro'] ?? '') . ' – ' . ($loja['cidade'] ?? '') . ' – ' . ($loja['uf'] ?? '')); ?><br>
        CEP: <?php echo h($loja['cep'] ?? ''); ?>
      </p>

      <?php if ($cnpjLoja): ?>
      <h3>Outras informações</h3>
      <p class="ml-texto">
        CNPJ: <?php echo h($cnpjLoja); ?>
      </p>
      <?php endif; ?>

      <p class="ml-rodape">
        O site é gratuito para os usuários e todos os preços apresentados no cardápio são definidos pela própria loja.
      </p>
    </div>

    <div class="ml-conteudo" id="tab-horario" style="display:none;">
      <ul class="ml-horario-lista">
        <?php
        $dias = [
          'seg' => 'Segunda-feira',
          'ter' => 'Terça-feira',
          'qua' => 'Quarta-feira',
          'qui' => 'Quinta-feira',
          'sex' => 'Sexta-feira',
          'sab' => 'Sábado',
          'dom' => 'Domingo',
        ];
        foreach ($dias as $sigla => $rotulo):
          $abre    = $loja["hora_{$sigla}_abre"]  ?? '';
          $fecha   = $loja["hora_{$sigla}_fecha"] ?? '';
          $fechado = !empty($loja["hora_{$sigla}_fechado"]);
        ?>
          <li>
            <span><?php echo h($rotulo); ?></span>
            <span>
              <?php
              if ($fechado || !$abre || !$fecha) {
                echo 'Fechado';
              } else {
                echo h($abre) . ' às ' . h($fecha);
              }
              ?>
            </span>
          </li>
        <?php endforeach; ?>
      </ul>
      <p class="ml-rodape">
        Horários configurados no painel da loja.
      </p>
    </div>

    <div class="ml-conteudo" id="tab-pagamento" style="display:none;">
      <h3>Pagamento na entrega</h3>
      <ul class="ml-pay-lista">
        <li>Dinheiro</li>
        <li>Cartão de débito</li>
        <li>Cartão de crédito</li>
        <li>PIX</li>
      </ul>
      <p class="ml-rodape">
        Formas de pagamento também podem ser detalhadas no atendimento pelo WhatsApp.
      </p>
    </div>
  </div>
</div>

<!-- MODAL PRODUTO (CLIQUE NO CARD) -->
<div class="modal-backdrop" id="modalProduto">
  <div class="modal modal-produto">
    <button type="button" class="modal-close" id="mpFechar">×</button>
    <div class="modal-produto-grid">
      <div class="modal-produto-img">
        <img id="mpImg" src="" alt="">
      </div>
      <div class="modal-produto-info">
        <div class="mp-nome" id="mpNome"></div>
        <div class="mp-desc" id="mpDesc"></div>
        <div class="mp-detalhe" id="mpDetalhe"></div>

        <div class="mp-preco" id="mpPrecoArea">
          <span id="mpPreco"></span>
          <small id="mpPrecoOriginal" style="display:none;"></small>
        </div>

        <form id="formProduto" method="post" action="carrinho.php">
          <input type="hidden" name="acao" value="add">
          <input type="hidden" name="id" id="mpId">
          <input type="hidden" name="nome" id="mpNomeInput">
          <input type="hidden" name="preco" id="mpPrecoInput">
          <input type="hidden" name="qtd" id="mpQtdInput">

          <label class="mp-label">Algum comentário?</label>
          <textarea name="comentario" maxlength="140"
                    placeholder="Ex: tirar a cebola, maionese à parte etc."></textarea>

          <div class="mp-footer">
            <div class="mp-qtd">
              <button type="button" class="mp-qtd-btn" id="mpMenos">−</button>
              <span id="mpQtd">1</span>
              <button type="button" class="mp-qtd-btn" id="mpMais">+</button>
            </div>
            <button type="submit" class="btn btn-red mp-add" id="mpBtnAdicionar">
              Adicionar • <span id="mpTotalBtn"></span>
            </button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<script>
function filtrar() {
  const termo1 = (document.getElementById('busca')?.value || '');
  const termo2 = (document.getElementById('buscaTopo')?.value || '');
  const termo  = (termo1 + ' ' + termo2).toLowerCase().trim();

  const cards = document.querySelectorAll('.card-produto');
  cards.forEach(card => {
    const nome = (card.dataset.nome || '').toLowerCase();
    const desc = (card.dataset.desc  || '').toLowerCase();
    if (!termo || nome.includes(termo) || desc.includes(termo)) {
      card.style.display = '';
    } else {
      card.style.display = 'none';
    }
  });
}

document.getElementById('busca').addEventListener('input', filtrar);
document.getElementById('buscaTopo').addEventListener('input', filtrar);

/* === MODAL ENTREGA / RETIRADA === */
const modalEntrega      = document.getElementById('modalEntrega');
const btnTipoEntrega    = document.getElementById('btnTipoEntrega');
const textoTipoEntrega  = document.getElementById('textoTipoEntrega');
let   entregaSelecionada = 'Entrega';

btnTipoEntrega.addEventListener('click', () => {
  modalEntrega.style.display = 'flex';
});

modalEntrega.addEventListener('click', (e) => {
  if (e.target === modalEntrega) modalEntrega.style.display = 'none';
});

document.querySelectorAll('#opcoesEntrega .modal-option').forEach(opt => {
  opt.addEventListener('click', () => {
    document.querySelectorAll('#opcoesEntrega .modal-option')
      .forEach(o => o.classList.remove('active'));
    opt.classList.add('active');
    entregaSelecionada = opt.getAttribute('data-tipo');
  });
});

document.getElementById('btnConfirmarEntrega').addEventListener('click', () => {
  textoTipoEntrega.textContent = entregaSelecionada;
  modalEntrega.style.display   = 'none';
});

/* === MODAL HORÁRIO === */
const modalHorario  = document.getElementById('modalHorario');
const btnDiaEntrega = document.getElementById('btnDiaEntrega');

btnDiaEntrega.addEventListener('click', () => {
  modalHorario.style.display = 'flex';
});

modalHorario.addEventListener('click', (e) => {
  if (e.target === modalHorario) modalHorario.style.display = 'none';
});

document.getElementById('btnConfirmarHorario').addEventListener('click', () => {
  modalHorario.style.display = 'none';
});

/* === MODAL LOJA (Sobre / Horário / Pagamento) === */
const modalLoja    = document.getElementById('modalLoja');
const btnSobreLoja = document.getElementById('btnSobreLoja');
const mlFechar     = document.getElementById('mlFechar');

btnSobreLoja.addEventListener('click', () => {
  modalLoja.style.display = 'flex';
});

mlFechar.addEventListener('click', () => {
  modalLoja.style.display = 'none';
});

modalLoja.addEventListener('click', (e) => {
  if (e.target === modalLoja) modalLoja.style.display = 'none';
});

document.querySelectorAll('.ml-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const alvo = tab.dataset.tab;

    document.querySelectorAll('.ml-tab')
      .forEach(t => t.classList.remove('active'));
    tab.classList.add('active');

    document.querySelectorAll('.ml-conteudo')
      .forEach(c => c.style.display = 'none');
    document.getElementById('tab-' + alvo).style.display = 'block';
  });
});
</script>

<script src="assets/produto-modal.js?v=1"></script>
</body>
</html>
